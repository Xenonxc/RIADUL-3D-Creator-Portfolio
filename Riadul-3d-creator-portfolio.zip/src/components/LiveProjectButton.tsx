import React from 'react';

interface LiveProjectButtonProps {
  onClick?: () => void;
  label?: string;
  className?: string;
  href?: string;
}

export const LiveProjectButton: React.FC<LiveProjectButtonProps> = ({
  onClick,
  label = "Live Project",
  className = "",
  href,
}) => {
  const content = (
    <span className="flex items-center justify-center gap-2">
      {label}
    </span>
  );

  const baseClasses = `
    inline-flex items-center justify-center rounded-full
    border-2 border-[#D7E2EA] text-[#D7E2EA]
    px-8 py-3 sm:px-10 sm:py-3.5
    text-sm sm:text-base font-medium uppercase tracking-widest
    transition-all duration-300 hover:bg-[#D7E2EA]/10 hover:scale-[1.02] active:scale-[0.98]
    cursor-pointer select-none ${className}
  `.trim();

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={baseClasses}>
        {content}
      </a>
    );
  }

  return (
    <button onClick={onClick} className={baseClasses} type="button">
      {content}
    </button>
  );
};
