import React from 'react';
import { ArrowUp, Mail, Twitter, Instagram, Linkedin } from 'lucide-react';
import { ContactButton } from './ContactButton';

interface FooterSectionProps {
  onOpenContact: () => void;
}

export const FooterSection: React.FC<FooterSectionProps> = ({ onOpenContact }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="relative z-20 bg-[#0C0C0C] text-[#D7E2EA] pt-20 pb-12 px-6 md:px-10 border-t border-white/10 select-none">
      <div className="max-w-6xl mx-auto flex flex-col gap-12">
        {/* Top Call to Action */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-white/10">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#B600A8] font-semibold">Ready to collaborate?</span>
            <h2 className="hero-heading text-4xl sm:text-5xl md:text-6xl font-black uppercase tracking-tight mt-2">
              Let's create together
            </h2>
          </div>
          <ContactButton onClick={onOpenContact} label="Get In Touch" />
        </div>

        {/* Links and Info */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 text-sm text-[#D7E2EA]/70">
          <div className="flex flex-col gap-1">
            <span className="font-bold text-white uppercase tracking-wider text-base">RIADUL -- 3D Creator</span>
            <p className="text-xs text-[#D7E2EA]/50">Crafting high-impact 3D visuals, motion graphics, and web experiences.</p>
          </div>

          {/* Socials */}
          <div className="flex items-center gap-6 text-xs uppercase tracking-widest font-medium">
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Twitter className="w-4 h-4" /> Twitter
            </a>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Instagram className="w-4 h-4" /> Instagram
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Linkedin className="w-4 h-4" /> LinkedIn
            </a>
          </div>

          {/* Scroll to Top */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 p-3 rounded-full bg-white/5 border border-white/10 hover:bg-white/15 transition-all text-xs uppercase tracking-widest cursor-pointer"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-4 h-4" /> Top
          </button>
        </div>

        {/* Copyright */}
        <div className="text-center sm:text-left text-xs text-[#D7E2EA]/40 pt-4 border-t border-white/5">
          &copy; {new Date().getFullYear()} RIADUL. All rights reserved.
        </div>
      </div>
    </footer>
  );
};
