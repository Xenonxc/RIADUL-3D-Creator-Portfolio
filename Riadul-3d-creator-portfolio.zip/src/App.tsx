import React, { useState } from 'react';
import { HeroSection } from './components/HeroSection';
import { MarqueeSection } from './components/MarqueeSection';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { ProjectsSection } from './components/ProjectsSection';
import { FooterSection } from './components/FooterSection';
import { ContactModal } from './components/ContactModal';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ExternalLink, Sparkles } from 'lucide-react';

export default function App() {
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [activeProjectModal, setActiveProjectModal] = useState<string | null>(null);

  return (
    <main className="w-full min-h-screen bg-[#0C0C0C] text-[#D7E2EA] font-['Kanit',sans-serif] overflow-x-clip selection:bg-[#B600A8] selection:text-white">
      {/* 1. HERO SECTION */}
      <HeroSection onOpenContact={() => setIsContactOpen(true)} />

      {/* 2. MARQUEE SECTION */}
      <MarqueeSection />

      {/* 3. ABOUT SECTION */}
      <AboutSection onOpenContact={() => setIsContactOpen(true)} />

      {/* 4. SERVICES SECTION */}
      <ServicesSection />

      {/* 5. PROJECTS SECTION */}
      <ProjectsSection onOpenProject={(name) => setActiveProjectModal(name)} />

      {/* FOOTER */}
      <FooterSection onOpenContact={() => setIsContactOpen(true)} />

      {/* CONTACT MODAL */}
      <ContactModal isOpen={isContactOpen} onClose={() => setIsContactOpen(false)} />

      {/* LIVE PROJECT PREVIEW MODAL */}
      <AnimatePresence>
        {activeProjectModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveProjectModal(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-[#121212] border border-[#D7E2EA]/20 rounded-[32px] p-6 sm:p-8 text-[#D7E2EA] z-10 shadow-2xl"
            >
              <button
                onClick={() => setActiveProjectModal(null)}
                className="absolute top-6 right-6 p-2 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/15 transition-all cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-[#B600A8] font-semibold text-xs uppercase tracking-widest mb-2">
                <Sparkles className="w-4 h-4" /> Live Interactive Case Study
              </div>
              <h2 className="text-3xl sm:text-4xl font-black uppercase text-white mb-4">
                {activeProjectModal}
              </h2>
              <p className="text-sm text-[#D7E2EA]/70 mb-6 leading-relaxed">
                Experience high-fidelity 3D renderings, real-time lighting interaction, and immersive motion design generated specifically for {activeProjectModal}.
              </p>

              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 flex flex-col items-center justify-center text-center gap-4">
                <p className="text-xs text-[#D7E2EA]/60 uppercase tracking-widest">
                  3D Canvas Scene Loaded
                </p>
                <button
                  onClick={() => setIsContactOpen(true)}
                  className="px-6 py-3 rounded-full bg-white text-[#0C0C0C] font-bold text-xs uppercase tracking-widest hover:bg-[#D7E2EA] transition-colors cursor-pointer flex items-center gap-2"
                >
                  Request Full 3D Asset Package <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </main>
  );
}
